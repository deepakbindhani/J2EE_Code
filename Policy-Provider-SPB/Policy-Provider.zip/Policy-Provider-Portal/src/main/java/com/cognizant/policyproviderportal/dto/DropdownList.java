package com.cognizant.policyproviderportal.dto;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
