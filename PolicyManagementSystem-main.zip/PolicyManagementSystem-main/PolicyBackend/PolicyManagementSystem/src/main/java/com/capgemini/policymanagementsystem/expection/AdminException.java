package com.capgemini.policymanagementsystem.expection;

public class AdminException extends Exception
{
	private static final long serialVersionUID = -470180507998010368L;

	public AdminException() {
		super();
	}

	public AdminException(final String message) {
		super(message);
	}

}
