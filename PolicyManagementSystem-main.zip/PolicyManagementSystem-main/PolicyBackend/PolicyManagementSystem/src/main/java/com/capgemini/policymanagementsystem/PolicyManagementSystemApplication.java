package com.capgemini.policymanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolicyManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicyManagementSystemApplication.class, args);
	}

}
