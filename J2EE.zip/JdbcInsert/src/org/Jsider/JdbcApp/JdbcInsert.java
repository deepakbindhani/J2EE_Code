package org.Jsider.JdbcApp;
public class JdbcInsert
{
	public static void main(String[] args) 
	{

	}

}
