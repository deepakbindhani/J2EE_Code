package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
@EnableFeignClients
@SpringBootApplication
public class PolicyManagementConsumerFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicyManagementConsumerFeignApplication.class, args);
		System.out.println("Feign Client . . .");
	}
	
	

}
