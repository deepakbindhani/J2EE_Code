package com.example.policymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.policymanagement.entity.Policy;

import java.util.List;


public interface PolicyRepository extends JpaRepository<Policy,Long> {

    public Policy findByPolicyName(String policyName);
    public List<Policy> findAll();
    public Policy save(Policy policy);
    
   
    

}
