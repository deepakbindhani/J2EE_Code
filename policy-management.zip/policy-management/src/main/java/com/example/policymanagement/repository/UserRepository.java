package com.example.policymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.policymanagement.entity.User;

import java.util.List;

import javax.validation.Valid;


public interface UserRepository extends JpaRepository<User, Long> {
    List<User> findByFirstName(String firstName);
    User findByUserId(String userId);
    User findByEmail(String email);
    User save(User user);
    
    
}
