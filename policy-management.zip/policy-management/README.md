# Policy management application
A small spring boot project to demonstrate basic features.

Triple cover insurance company has admin and user as 2 types of users..
